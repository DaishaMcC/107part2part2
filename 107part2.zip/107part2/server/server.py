from flask import Flask,request
import json

app = Flask(__name__)
@app.get("/")
def home():
    return "Hello from Flask"


# create another API that redirects you to a test

@app.get("/test")
def test():
    return "Hello from the test"

@app.route("/server")
def server():
    server=request.environ["SERVER_SOFTWARE"]
    return server

@app.get("/api/about")
def about():
    myname ={"name":"daisha mccutcheon"}
    return json.dumps(myname)

app.run(debug=True)